/*
 * random.c - RP2040 RNG, implementing the same contract as the
 *            original neug.c/random.c (see random.h).
 *
 * bn.c (bn256_random, used by ecc.c for ECDSA nonce k) calls
 * random_bytes_get()/random_bytes_free(), NOT random_gen(). Both
 * must be provided or the link (or, worse, the ECDSA signature)
 * will be silently wrong.
 *
 * Entropy source: RP2040 ring-oscillator RNG (rosc_hw->randombit),
 * whitened with SHA-256, plus the SDK's own get_rand_32() (which
 * itself mixes rosc jitter with the always-running timer).
 */
#include <string.h>
#include "pico/stdlib.h"
#include "pico/rand.h"
#include "hardware/structs/rosc.h"
#include "sha256.h"
#include "random.h"

static uint8_t pool[32];
static int pool_valid;

static uint32_t rosc_bit_bytes(void)
{
  uint32_t k = 0;
  for (int i = 0; i < 32; i++)
    {
      k = (k << 1) | (rosc_hw->randombit & 1);
      /* a few cycles between samples so we are not just reading
         the same oscillator phase repeatedly */
      busy_wait_us_32(2);
    }
  return k;
}

static void refill_pool(void)
{
  uint32_t raw[16];
  sha256_context ctx;

  for (int i = 0; i < 16; i++)
    raw[i] = get_rand_32() ^ rosc_bit_bytes();

  /* Whiten: raw ring-oscillator/timer mix is not uniform on its
     own, so condense 64 bytes of raw material into a 32-byte
     pool with SHA-256, same idea as neug's CRC32+SHA256 chain. */
  sha256_start(&ctx);
  sha256_update(&ctx, (uint8_t *)raw, sizeof(raw));
  sha256_finish(&ctx, pool);
  pool_valid = 1;
}

void random_init(void)
{
  pool_valid = 0;
  refill_pool();
}

void random_fini(void)
{
  memset(pool, 0, sizeof(pool));
  pool_valid = 0;
}

const uint8_t *random_bytes_get(void)
{
  if (!pool_valid)
    refill_pool();
  return pool;
}

void random_bytes_free(const uint8_t *p)
{
  (void)p;
  /* Pool is single-use: force a reseed next time so the same 32
     bytes are never handed out twice. */
  pool_valid = 0;
}

void random_get_salt(uint8_t *p)
{
  const uint8_t *r = random_bytes_get();
  memcpy(p, r, 8);
  random_bytes_free(r);
}

int random_gen(void *arg, unsigned char *output, size_t output_len)
{
  (void)arg;
  size_t done = 0;
  while (done < output_len)
    {
      const uint8_t *r = random_bytes_get();
      size_t n = output_len - done;
      if (n > sizeof(pool)) n = sizeof(pool);
      memcpy(output + done, r, n);
      random_bytes_free(r);
      done += n;
    }
  return 0;
}
