/* PicoU2F — single poll loop. No chopstx, no PWM thread, no USB thread. */
#include "pico/stdlib.h"
#include "tusb.h"
#include "platform.h"
#include "u2f-apdu.h"
#include "u2f-hid.h"

int main(void) {
  platform_init();
  tusb_init();
  u2f_apdu_init();

  while (1) {
    tud_task();
    platform_poll();
    u2f_hid_flush();
  }
}

void tud_hid_set_report_cb(uint8_t itf, uint8_t report_id,
                           hid_report_type_t type,
                           uint8_t const *buffer, uint16_t bufsize) {
  (void)itf; (void)report_id; (void)type;
  if (bufsize >= 64) u2f_hid_rx(buffer);
}

uint16_t tud_hid_get_report_cb(uint8_t itf, uint8_t report_id,
                               hid_report_type_t type,
                               uint8_t *buffer, uint16_t reqlen) {
  (void)itf; (void)report_id; (void)type; (void)buffer; (void)reqlen;
  return 0;
}
