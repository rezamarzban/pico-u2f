#pragma once
#include <stdint.h>

/* Generates the device key on first boot (reads flash, checks its
 * self hash, regenerates via the hardware RNG if invalid). */
void u2f_apdu_init (void);

/* Processes one raw U2F APDU (REGISTER / AUTHENTICATE / VERSION /
 * vendor ATTESTATION_CERT) and writes the response + status word
 * into resp/resp_len. Return value is currently always 0; errors
 * are reported via the U2F status word appended to resp. */
int u2f_apdu_command_do (uint8_t *apdu, uint32_t len,
                         uint8_t *resp, uint32_t *resp_len);
