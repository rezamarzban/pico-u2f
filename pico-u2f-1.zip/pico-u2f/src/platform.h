#pragma once
#include <stdint.h>
#include <stddef.h>

void platform_init(void);
void platform_poll(void);

int  user_presence_get(void);
void user_presence_reset(void);
void led_wink(void);

void flash_erase_page(uintptr_t addr);
void flash_write(uintptr_t addr, const uint8_t *data, size_t len);
