#pragma once
#include <stdint.h>
void u2f_hid_rx(uint8_t const *rpt);
void u2f_hid_flush(void);
