#include "tusb.h"
#include <string.h>

/* pid.codes 1209 / product 0e90 — change if you ship. */
#define USB_VID 0x1209
#define USB_PID 0x0e90

enum { ITF_HID = 0, EPNUM_HID = 1 };

static const tusb_desc_device_t desc_device = {
  .bLength = sizeof(tusb_desc_device_t),
  .bDescriptorType = TUSB_DESC_DEVICE,
  .bcdUSB = 0x0200,
  .bDeviceClass = 0,
  .bDeviceSubClass = 0,
  .bDeviceProtocol = 0,
  .bMaxPacketSize0 = CFG_TUD_ENDPOINT0_SIZE,
  .idVendor = USB_VID,
  .idProduct = USB_PID,
  .bcdDevice = 0x0100,
  .iManufacturer = 1,
  .iProduct = 2,
  .iSerialNumber = 3,
  .bNumConfigurations = 1,
};

/* FIDO Alliance HID usage page 0xF1D0, usage 0x01, 64-byte reports. */
static const uint8_t desc_hid_report[] = {
  0x06, 0xd0, 0xf1, /* Usage Page (FIDO) */
  0x09, 0x01,       /* Usage (U2FHID) */
  0xa1, 0x01,
  0x09, 0x20,       /* Usage (Data In) */
  0x15, 0x00, 0x26, 0xff, 0x00,
  0x75, 0x08, 0x95, 0x40,
  0x81, 0x02,
  0x09, 0x21,       /* Usage (Data Out) */
  0x15, 0x00, 0x26, 0xff, 0x00,
  0x75, 0x08, 0x95, 0x40,
  0x91, 0x02,
  0xc0
};

#define CONFIG_TOTAL_LEN (TUD_CONFIG_DESC_LEN + TUD_HID_DESC_LEN)

static const uint8_t desc_configuration[] = {
  TUD_CONFIG_DESCRIPTOR(1, 1, 0, CONFIG_TOTAL_LEN, 0, 100),
  TUD_HID_DESCRIPTOR(ITF_HID, 0, 0, sizeof(desc_hid_report),
                     0x80 | EPNUM_HID, 64, 5),
};

static const char *string_desc_arr[] = {
  (const char[]){ 0x09, 0x04 },
  "PicoU2F",
  "Pico U2F Token",
  "0",
};

uint8_t const *tud_descriptor_device_cb(void) { return (uint8_t const *)&desc_device; }
uint8_t const *tud_hid_descriptor_report_cb(uint8_t itf) { (void)itf; return desc_hid_report; }
uint8_t const *tud_descriptor_configuration_cb(uint8_t index) { (void)index; return desc_configuration; }

static uint16_t _desc_str[32];
uint16_t const *tud_descriptor_string_cb(uint8_t index, uint16_t langid) {
  (void)langid;
  uint8_t chr_count;
  if (index == 0) {
    memcpy(&_desc_str[1], string_desc_arr[0], 2);
    chr_count = 1;
  } else {
    if (index >= 4) return NULL;
    const char *s = string_desc_arr[index];
    chr_count = (uint8_t)strlen(s);
    if (chr_count > 31) chr_count = 31;
    for (uint8_t i = 0; i < chr_count; i++) _desc_str[1 + i] = s[i];
  }
  _desc_str[0] = (TUSB_DESC_STRING << 8) | (2 * chr_count + 2);
  return _desc_str;
}
