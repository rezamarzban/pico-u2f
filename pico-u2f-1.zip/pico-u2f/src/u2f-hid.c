/* u2f-hid.c — state machine, no chopstx thread.
 * Original used a dedicated USB thread; TinyUSB tud_task() is the wait.
 */
#include <string.h>
#include "tusb.h"
#include "u2f-hid.h"
#include "u2f-apdu.h"
#include "platform.h"

#define HID_RPT_SIZE 64
#define TYPE_INIT    0x80
#define CID_BROADCAST 0xffffffffu
#define U2FHID_PING  (TYPE_INIT | 0x01)
#define U2FHID_MSG   (TYPE_INIT | 0x03)
#define U2FHID_INIT  (TYPE_INIT | 0x06)
#define U2FHID_WINK  (TYPE_INIT | 0x08)
#define U2FHID_ERROR (TYPE_INIT | 0x3f)
#define MAX_MSGLEN   1024

static uint32_t next_cid = 0x0a000001;
static uint32_t cid;
static uint8_t  cmd;
static uint8_t  seq;
static uint16_t msg_len, msg_pos;
static uint8_t  msg[MAX_MSGLEN];
static uint8_t  tx[MAX_MSGLEN];
static uint16_t tx_len, tx_off;
static uint8_t  tx_seq;
static uint32_t tx_cid;
static uint8_t  tx_cmd;
static int      tx_busy;

static uint32_t rd_cid(const uint8_t *r) {
  return ((uint32_t)r[0] << 24) | ((uint32_t)r[1] << 16) | ((uint32_t)r[2] << 8) | r[3];
}
static void wr_cid(uint8_t *r, uint32_t c) {
  r[0] = c >> 24; r[1] = c >> 16; r[2] = c >> 8; r[3] = c;
}

static void send_start(uint32_t c, uint8_t command, const uint8_t *p, uint16_t n) {
  memcpy(tx, p, n);
  tx_len = n; tx_off = 0; tx_seq = 0; tx_cid = c; tx_cmd = command; tx_busy = 1;
}

void u2f_hid_flush(void) {
  if (!tx_busy || !tud_hid_ready()) return;
  uint8_t rpt[HID_RPT_SIZE] = {0};
  wr_cid(rpt, tx_cid);
  if (tx_off == 0) {
    rpt[4] = tx_cmd;
    rpt[5] = tx_len >> 8;
    rpt[6] = tx_len;
    uint16_t n = tx_len < 57 ? tx_len : 57;
    memcpy(rpt + 7, tx, n);
    tx_off = n;
  } else {
    rpt[4] = tx_seq++;
    uint16_t n = (tx_len - tx_off) < 59 ? (tx_len - tx_off) : 59;
    memcpy(rpt + 5, tx + tx_off, n);
    tx_off += n;
  }
  tud_hid_report(0, rpt, HID_RPT_SIZE);
  if (tx_off >= tx_len) tx_busy = 0;
}

void u2f_hid_rx(uint8_t const *rpt) {
  uint32_t c = rd_cid(rpt);
  if (rpt[4] & TYPE_INIT) {
    uint8_t command = rpt[4];
    uint16_t n = ((uint16_t)rpt[5] << 8) | rpt[6];
    if (command == U2FHID_INIT) {
      uint8_t resp[17];
      memcpy(resp, rpt + 7, 8);
      uint32_t assigned = (c == CID_BROADCAST) ? next_cid++ : c;
      wr_cid(resp + 8, assigned);
      resp[12] = 2; resp[13] = 1; resp[14] = 0; resp[15] = 0; resp[16] = 0x01;
      cid = assigned;
      send_start(c, U2FHID_INIT, resp, 17);
      return;
    }
    if (command == U2FHID_WINK) { led_wink(); send_start(c, U2FHID_WINK, NULL, 0); return; }
    if (command == U2FHID_PING) { send_start(c, U2FHID_PING, rpt + 7, n < 57 ? n : 57); return; }
    cid = c; cmd = command; msg_len = n; msg_pos = 0; seq = 0;
    uint16_t take = n < 57 ? n : 57;
    memcpy(msg, rpt + 7, take);
    msg_pos = take;
  } else {
    if ((rpt[4] & 0x7f) != seq) return;
    seq++;
    uint16_t take = (msg_len - msg_pos) < 59 ? (msg_len - msg_pos) : 59;
    memcpy(msg + msg_pos, rpt + 5, take);
    msg_pos += take;
  }
  if ((rpt[4] & TYPE_INIT) == 0 || msg_pos < msg_len) {
    if (msg_pos < msg_len) return;
  }
  if (cmd == U2FHID_MSG) {
    uint32_t resp_len = 0;
    static uint8_t resp[1024];
    u2f_apdu_command_do(msg, msg_len, resp, &resp_len);
    send_start(cid, U2FHID_MSG, resp, (uint16_t)resp_len);
  }
}
