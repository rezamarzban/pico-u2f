/* platform.c — Pico GPIO/flash glue.
 * Replaces the STM32/EFM32 platform.c + pbt.c/csn.c/uvoid.c drivers.
 */
#include <string.h>
#include "platform.h"
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/flash.h"
#include "hardware/sync.h"

#define PIN_BTN 15
#define PIN_LED 25
#define PRESENCE_MS 8000

static uint32_t presence_until;
static uint32_t wink_until;
static uint32_t wink_last;

void platform_init(void)
{
  gpio_init(PIN_BTN);
  gpio_set_dir(PIN_BTN, GPIO_IN);
  gpio_pull_up(PIN_BTN);
  gpio_init(PIN_LED);
  gpio_set_dir(PIN_LED, GPIO_OUT);
}

void platform_poll(void)
{
  uint32_t now = to_ms_since_boot(get_absolute_time());
  static int prev = 1;
  int cur = gpio_get(PIN_BTN);

  if (prev == 1 && cur == 0)
    presence_until = now + PRESENCE_MS;
  prev = cur;

  if (now < wink_until)
    {
      if (now - wink_last > 80)
        {
          gpio_xor_mask(1u << PIN_LED);
          wink_last = now;
        }
    }
  else
    {
      gpio_put(PIN_LED, presence_until > now);
    }
}

int user_presence_get(void)
{
  return to_ms_since_boot(get_absolute_time()) < presence_until;
}

void user_presence_reset(void) { presence_until = 0; }

void led_wink(void)
{
  wink_until = to_ms_since_boot(get_absolute_time()) + 1600;
}

/* --- flash ---
 * addr is always an XIP-mapped pointer (XIP_BASE + offset), same
 * convention the original STM32 code used with linker-script
 * placed globals: callers just take the address of "their" struct
 * and pass it straight through.
 */

void flash_erase_page(uintptr_t addr)
{
  uint32_t off = (uint32_t)(addr - (uintptr_t)XIP_BASE);
  off &= ~(FLASH_SECTOR_SIZE - 1);
  uint32_t irq = save_and_disable_interrupts();
  flash_range_erase(off, FLASH_SECTOR_SIZE);
  restore_interrupts(irq);
}

/* RP2040 can only program whole 256-byte pages, and only after they
 * have been erased. We read-modify-write every page the requested
 * range touches. Caller is responsible for having erased the sector
 * first if it needs old bits cleared to 0xff (device_key_gen and
 * u2f_attestation_cert_initialize both do this, matching the
 * original erase-then-write sequence).
 */
void flash_write(uintptr_t addr, const uint8_t *data, size_t len)
{
  uint32_t off = (uint32_t)(addr - (uintptr_t)XIP_BASE);
  size_t done = 0;

  while (done < len)
    {
      uint32_t page_off = (off + done) & ~(FLASH_PAGE_SIZE - 1);
      uint32_t into = (off + done) - page_off;
      uint32_t chunk = FLASH_PAGE_SIZE - into;
      if (chunk > len - done) chunk = len - done;

      uint8_t page[FLASH_PAGE_SIZE];
      memcpy(page, (const void *)(XIP_BASE + page_off), FLASH_PAGE_SIZE);
      memcpy(page + into, data + done, chunk);

      uint32_t irq = save_and_disable_interrupts();
      flash_range_program(page_off, page, FLASH_PAGE_SIZE);
      restore_interrupts(irq);

      done += chunk;
    }
}
