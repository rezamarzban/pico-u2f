/*
 * u2f-apdu.c - U2F apdu commands (Raspberry Pi Pico / RP2040 port)
 *
 * Original: Copyright (C) 2017-2019 Sergei Glushchenko
 *           <gl.sergei@gmail.com> — https://github.com/gl-sergei/u2f-token
 *
 * This file keeps the original register/authenticate algorithm
 * (HMAC-based key wrapping, no per-credential key storage) intact.
 * What changed for RP2040:
 *   - device key / counter / attestation cert live at fixed offsets
 *     in the last three flash sectors, addressed via XIP_BASE,
 *     instead of STM32 linker-script sections (.device.key etc)
 *   - flash page size is FLASH_SECTOR_SIZE (4096) not 1024
 *   - board.h / sys.h / pbt.h (STM32) -> platform.h (Pico)
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version. See COPYING.
 */

#include <stdint.h>
#include <string.h>
#include "sha256.h"
#include "ecc.h"
#include "hmac.h"
#include "random.h"
#include "platform.h"
#include "u2f-apdu.h"
#include "hardware/flash.h"
#include "hardware/sync.h"
#include "pico/stdlib.h"

#define CLA(apdu)  ((apdu)[0])
#define INS(apdu)  ((apdu)[1])
#define P1(apdu)   ((apdu)[2])
#define P2(apdu)   ((apdu)[3])
#define LC(apdu)   (((apdu)[4] << 16) | ((apdu)[5] << 8) | (apdu)[6])
#define DATA(apdu) ((apdu) + 7)

#define HASH_RES_SIZE            32

#define U2F_EC_KEY_SIZE          32
#define U2F_EC_POINT_SIZE        ((U2F_EC_KEY_SIZE * 2) + 1)
#define U2F_NONCE_SIZE           32
#define U2F_KH_SIZE              (HASH_RES_SIZE + U2F_NONCE_SIZE) /* 64 */
#define U2F_PRIV_K_SIZE          32
#define U2F_MAX_EC_SIG_SIZE      72
#define U2F_CTR_SIZE             4
#define U2F_APPID_SIZE           32
#define U2F_CHAL_SIZE            32

#define U2F_POINT_UNCOMPRESSED   0x04

typedef struct {
    uint8_t pointFormat;
    uint8_t x[U2F_EC_KEY_SIZE];
    uint8_t y[U2F_EC_KEY_SIZE];
} __attribute__ ((packed)) U2F_EC_POINT;

#define U2F_REGISTER             0x01
#define U2F_AUTHENTICATE         0x02
#define U2F_VERSION              0x03
#define U2F_ATTESTATION_CERT     0x40

#define U2F_REGISTER_ID          0x05

typedef struct {
    uint8_t chal[U2F_CHAL_SIZE];
    uint8_t appId[U2F_APPID_SIZE];
} __attribute__ ((packed)) U2F_REGISTER_REQ;

#define ATTESTATION_DER_MAX_LEN  512

typedef struct {
    uint8_t registerId;
    U2F_EC_POINT pubKey;
    uint8_t keyHandleLen;
    uint8_t keyHandle[U2F_KH_SIZE];
    uint8_t attCert[ATTESTATION_DER_MAX_LEN];
    uint8_t pad[2 + U2F_MAX_EC_SIG_SIZE];
} __attribute__ ((packed)) U2F_REGISTER_RESP;

#define U2F_AUTH_ENFORCE         0x03
#define U2F_AUTH_CHECK_ONLY      0x07
#define U2F_AUTH_FLAG_TUP        0x01

typedef struct {
    uint8_t chal[U2F_CHAL_SIZE];
    uint8_t appId[U2F_APPID_SIZE];
    uint8_t keyHandleLen;
    uint8_t keyHandle[U2F_KH_SIZE];
} __attribute__ ((packed)) U2F_AUTHENTICATE_REQ;

typedef struct {
    uint8_t flags;
    uint8_t ctr[U2F_CTR_SIZE];
    uint8_t sig[U2F_MAX_EC_SIG_SIZE];
    uint8_t pad[2];
} __attribute__ ((packed)) U2F_AUTHENTICATE_RESP;

typedef struct {
    uint8_t key[U2F_EC_KEY_SIZE];
    uint8_t der[ATTESTATION_DER_MAX_LEN];
} __attribute__ ((packed)) U2F_ATTESTATION_CERT_REQ;

#define U2F_SW_NO_ERROR                  0x9000
#define U2F_SW_WRONG_DATA                0x6A80
#define U2F_SW_CONDITIONS_NOT_SATISFIED  0x6985
#define U2F_SW_COMMAND_NOT_ALLOWED       0x6986
#define U2F_SW_INS_NOT_SUPPORTED         0x6D00
#define U2F_SW_WRONG_LENGTH              0x6700
#define U2F_SW_BAD_CLA                   0x6E00

/* ---- RP2040 flash layout: last 3 sectors of flash ----
 *
 *   sector N-3: device key  [0:32)=key  [32:64)=sha256(key)
 *   sector N-2: auth counter, one uint32_t slot per erase cycle
 *   sector N-1: attestation cert header + key + DER, written by
 *               the U2F_ATTESTATION_CERT vendor command (see
 *               tools/provision.py)
 *
 * Erased flash reads as 0xff, so an unprogrammed attestation
 * sector naturally reads der_len == 0xffffffff, which we use as
 * the "not yet provisioned" sentinel (same convention the STM32
 * version used with empty-attestation-cert.c).
 */

#define U2F_FLASH_TOP     (PICO_FLASH_SIZE_BYTES)
#define DEVKEY_OFF        (U2F_FLASH_TOP - 3 * FLASH_SECTOR_SIZE)
#define CTR_OFF           (U2F_FLASH_TOP - 2 * FLASH_SECTOR_SIZE)
#define CERT_OFF          (U2F_FLASH_TOP - 1 * FLASH_SECTOR_SIZE)

#define DEVKEY_ADDR       (XIP_BASE + DEVKEY_OFF)
#define CTR_BASE_ADDR     (XIP_BASE + CTR_OFF)
#define CERT_ADDR         (XIP_BASE + CERT_OFF)

struct attestation_cert_hdr {
    uint32_t der_len;   /* 0xffffffff => not provisioned yet */
};

static uint8_t device_key[U2F_PRIV_K_SIZE];
static uint32_t *ctr_addr = (uint32_t *) CTR_BASE_ADDR;

/* simple RNG interface, same shape as the original */
static int
rng (uint8_t *buf, size_t size)
{
  return random_gen (NULL, buf, size);
}

static void
device_key_gen (void)
{
  uint8_t key_hash[HASH_RES_SIZE];
  uint8_t stored_hash[HASH_RES_SIZE];
  sha256_context ctx;
  const uint8_t *flash_key = (const uint8_t *) DEVKEY_ADDR;

  memcpy (device_key, flash_key, U2F_PRIV_K_SIZE);
  memcpy (stored_hash, flash_key + U2F_PRIV_K_SIZE, HASH_RES_SIZE);

  sha256_start (&ctx);
  sha256_update (&ctx, device_key, U2F_PRIV_K_SIZE);
  sha256_finish (&ctx, key_hash);

  if (memcmp (key_hash, stored_hash, HASH_RES_SIZE) == 0)
    return; /* flash already holds a valid key */

  /* first boot (or corrupt flash): generate a fresh device key */
  rng (device_key, U2F_PRIV_K_SIZE);

  sha256_start (&ctx);
  sha256_update (&ctx, device_key, U2F_PRIV_K_SIZE);
  sha256_finish (&ctx, key_hash);

  flash_erase_page (DEVKEY_ADDR);
  flash_write (DEVKEY_ADDR, device_key, U2F_PRIV_K_SIZE);
  flash_write (DEVKEY_ADDR + U2F_PRIV_K_SIZE, key_hash, HASH_RES_SIZE);

  /* new device key => old counter values are meaningless */
  flash_erase_page (CTR_BASE_ADDR);
  ctr_addr = (uint32_t *) CTR_BASE_ADDR;
}

static void
new_private_key (uint8_t *app_id, uint8_t *nonce, uint8_t *private_key)
{
  hmac_sha256_context ctx;

  hmac_sha256_init (&ctx, device_key);
  hmac_sha256_update (&ctx, app_id, U2F_APPID_SIZE);
  hmac_sha256_update (&ctx, nonce, U2F_NONCE_SIZE);
  hmac_sha256_finish (&ctx, device_key, private_key);
}

static void
make_key_handle (uint8_t *private_key, uint8_t *app_id,
                 uint8_t *nonce, uint8_t *key_handle)
{
  hmac_sha256_context ctx;

  hmac_sha256_init (&ctx, device_key);
  hmac_sha256_update (&ctx, private_key, U2F_PRIV_K_SIZE);
  hmac_sha256_update (&ctx, app_id, U2F_APPID_SIZE);
  hmac_sha256_finish (&ctx, device_key, key_handle);

  memcpy (key_handle + HASH_RES_SIZE, nonce, U2F_NONCE_SIZE);
}

static int
recover_private_key (uint8_t *app_id, uint8_t *key_handle,
                     uint8_t key_handle_len, uint8_t *private_key)
{
  hmac_sha256_context ctx;
  uint8_t control_mac[HASH_RES_SIZE];

  if (key_handle_len != U2F_KH_SIZE)
    return -1;

  hmac_sha256_init (&ctx, device_key);
  hmac_sha256_update (&ctx, app_id, U2F_APPID_SIZE);
  hmac_sha256_update (&ctx, key_handle + HASH_RES_SIZE, U2F_NONCE_SIZE);
  hmac_sha256_finish (&ctx, device_key, private_key);

  hmac_sha256_init (&ctx, device_key);
  hmac_sha256_update (&ctx, private_key, U2F_PRIV_K_SIZE);
  hmac_sha256_update (&ctx, app_id, U2F_APPID_SIZE);
  hmac_sha256_finish (&ctx, device_key, control_mac);

  return memcmp (control_mac, key_handle, HASH_RES_SIZE);
}

static uint8_t
der_encode_uint (uint8_t *der, uint8_t *x, uint8_t x_len)
{
  uint8_t len = 0;

  der[len++] = 0x02;
  der[len++] = 0;

  while (x[0] == 0 && x_len > 1)
    {
      ++x;
      --x_len;
    }

  if (x[0] > 0x7f)
    der[len++] = 0;

  memcpy (der + len, x, x_len);
  len += x_len;

  der[1] = len - 2;

  return len;
}

static uint8_t
der_encode_sig (uint8_t *der, uint8_t *sig)
{
  uint8_t len = 0;

  der[len++] = 0x30;
  der[len++] = 0;

  len += der_encode_uint (der + len, sig, 32);
  len += der_encode_uint (der + len, sig + 32, 32);

  der[1] = len - 2;

  return len;
}

static int
attestation_cert_initialized (void)
{
  const struct attestation_cert_hdr *hdr =
    (const struct attestation_cert_hdr *) CERT_ADDR;
  return hdr->der_len != 0xffffffffu;
}

/* Layout inside the attestation sector, once provisioned:
 *   [0:4)              der_len (uint32_t)
 *   [4:4+32)            attestation private key
 *   [36:36+der_len)     DER certificate
 */
static uint32_t
attestation_der_len (void)
{
  const struct attestation_cert_hdr *hdr =
    (const struct attestation_cert_hdr *) CERT_ADDR;
  return hdr->der_len;
}

static const uint8_t *
attestation_key (void)
{
  return (const uint8_t *) (CERT_ADDR + 4);
}

static const uint8_t *
attestation_der (void)
{
  return (const uint8_t *) (CERT_ADDR + 4 + U2F_EC_KEY_SIZE);
}

static int
attestation_cert_initialize (uint32_t len, const U2F_ATTESTATION_CERT_REQ *req)
{
  uint32_t der_len;
  uint8_t hdr[4];

  if (len <= U2F_EC_KEY_SIZE)
    return -1;
  der_len = len - U2F_EC_KEY_SIZE;
  if (der_len > ATTESTATION_DER_MAX_LEN)
    return -1;

  flash_erase_page (CERT_ADDR);

  flash_write (CERT_ADDR + 4, req->key, U2F_EC_KEY_SIZE);
  flash_write (CERT_ADDR + 4 + U2F_EC_KEY_SIZE, req->der, der_len);

  /* header written last: this is what flips attestation_cert_initialized()
   * from false to true, so a power-loss mid-write leaves it correctly
   * "not provisioned" rather than pointing at half-written data. */
  hdr[0] = der_len & 0xff;
  hdr[1] = (der_len >> 8) & 0xff;
  hdr[2] = (der_len >> 16) & 0xff;
  hdr[3] = (der_len >> 24) & 0xff;
  flash_write (CERT_ADDR, hdr, 4);

  return 0;
}

static void
register_req_hash (U2F_REGISTER_REQ *req, U2F_REGISTER_RESP *resp,
                   uint8_t *hash)
{
  sha256_context ctx;
  uint8_t reserved = 0;

  sha256_start (&ctx);
  sha256_update (&ctx, &reserved, 1);
  sha256_update (&ctx, req->appId, U2F_APPID_SIZE);
  sha256_update (&ctx, req->chal, U2F_CHAL_SIZE);
  sha256_update (&ctx, resp->keyHandle, resp->keyHandleLen);
  sha256_update (&ctx, (uint8_t *) &resp->pubKey, sizeof (resp->pubKey));
  sha256_finish (&ctx, hash);
}

static int
u2f_register (U2F_REGISTER_REQ *req, U2F_REGISTER_RESP *resp)
{
  uint8_t private_key[U2F_PRIV_K_SIZE];
  uint8_t nonce[U2F_NONCE_SIZE];
  uint8_t hash[HASH_RES_SIZE];
  uint8_t sig[64];
  uint8_t sig_len;
  uint32_t der_len = attestation_der_len ();

  if (rng (nonce, U2F_NONCE_SIZE))
    return -1;

  new_private_key (req->appId, nonce, private_key);
  make_key_handle (private_key, req->appId, nonce, resp->keyHandle);

  if (ecc_compute_public_p256r1 (private_key, resp->pubKey.x))
    return -1;

  resp->registerId = U2F_REGISTER_ID;
  resp->pubKey.pointFormat = U2F_POINT_UNCOMPRESSED;
  resp->keyHandleLen = U2F_KH_SIZE;
  memcpy (resp->attCert, attestation_der (), der_len);

  register_req_hash (req, resp, hash);

  if (ecdsa_sign_p256r1 (hash, sig, attestation_key ()))
    return -1;

  sig_len = der_encode_sig (resp->attCert + der_len, sig);

  return 1                     /* registerId */
         + (int) sizeof (U2F_EC_POINT)
         + 1                   /* keyHandleLen */
         + U2F_KH_SIZE
         + (int) der_len
         + sig_len;
}

static uint32_t
u2f_read_ctr (void)
{
  const uint32_t *base = (const uint32_t *) CTR_BASE_ADDR;
  const int slots = FLASH_SECTOR_SIZE / (int) sizeof (uint32_t);

  while (*ctr_addr != 0xffffffffu)
    {
      if (ctr_addr - base == slots)
        break;
      ctr_addr++;
    }

  if (ctr_addr == base)
    return 0;

  return ctr_addr[-1];
}

static void
u2f_write_ctr (uint32_t val)
{
  const uint32_t *base = (const uint32_t *) CTR_BASE_ADDR;
  const int slots = FLASH_SECTOR_SIZE / (int) sizeof (uint32_t);

  while (*ctr_addr != 0xffffffffu)
    {
      if (ctr_addr - base == slots)
        {
          flash_erase_page (CTR_BASE_ADDR);
          ctr_addr = (uint32_t *) base;
          break;
        }
      ctr_addr++;
    }

  flash_write ((uintptr_t) ctr_addr, (uint8_t *) &val, sizeof (val));
}

static void
u2f_inc_ctr (void)
{
  u2f_write_ctr (u2f_read_ctr () + 1);
}

static void
auth_req_hash (U2F_AUTHENTICATE_REQ *req, U2F_AUTHENTICATE_RESP *resp,
               uint8_t *hash)
{
  sha256_context ctx;

  sha256_start (&ctx);
  sha256_update (&ctx, req->appId, U2F_APPID_SIZE);
  sha256_update (&ctx, &resp->flags, 1);
  sha256_update (&ctx, resp->ctr, 4);
  sha256_update (&ctx, req->chal, U2F_CHAL_SIZE);
  sha256_finish (&ctx, hash);
}

static int
u2f_authenticate (U2F_AUTHENTICATE_REQ *req, U2F_AUTHENTICATE_RESP *resp)
{
  uint8_t private_key[U2F_PRIV_K_SIZE];
  uint8_t hash[HASH_RES_SIZE];
  uint8_t sig[64];
  uint8_t sig_len;
  uint32_t ctr;

  resp->flags = U2F_AUTH_FLAG_TUP;

  ctr = u2f_read_ctr ();
  resp->ctr[0] = (ctr >> 24) & 0xff;
  resp->ctr[1] = (ctr >> 16) & 0xff;
  resp->ctr[2] = (ctr >>  8) & 0xff;
  resp->ctr[3] =  ctr        & 0xff;

  auth_req_hash (req, resp, hash);

  if (recover_private_key (req->appId, req->keyHandle,
                           req->keyHandleLen, private_key))
    return -1;

  if (ecdsa_sign_p256r1 (hash, sig, private_key))
    return -1;

  sig_len = der_encode_sig (resp->sig, sig);

  return 1 + U2F_CTR_SIZE + sig_len;
}

static int
u2f_version (uint8_t *resp)
{
  memcpy (resp, "U2F_V2", 6);
  return 6;
}

static void
append_sw (uint8_t *msg, uint32_t *len, uint16_t sw)
{
  msg[(*len)++] = (sw >> 8) & 0xff;
  msg[(*len)++] = sw & 0xff;
}

static void
u2f_apdu_error (uint8_t *msg, uint32_t *len, uint16_t sw)
{
  *len = 0;
  append_sw (msg, len, sw);
}

void
u2f_apdu_init (void)
{
  device_key_gen ();
}

int
u2f_apdu_command_do (uint8_t *apdu, uint32_t len,
                     uint8_t *resp, uint32_t *resp_len)
{
  uint32_t Lc;
  int ret;

  Lc = LC (apdu);

  if (CLA (apdu) != 0)
    {
      u2f_apdu_error (resp, resp_len, U2F_SW_BAD_CLA);
      return 0;
    }

  if (Lc + 7 > len)
    {
      u2f_apdu_error (resp, resp_len, U2F_SW_WRONG_LENGTH);
      return 0;
    }

  switch (INS (apdu))
    {
    case U2F_REGISTER:
      if (!attestation_cert_initialized ())
        {
          u2f_apdu_error (resp, resp_len, U2F_SW_COMMAND_NOT_ALLOWED);
          break;
        }
      if (Lc != sizeof (U2F_REGISTER_REQ))
        {
          u2f_apdu_error (resp, resp_len, U2F_SW_WRONG_LENGTH);
          break;
        }
      if (!user_presence_get ())
        {
          u2f_apdu_error (resp, resp_len, U2F_SW_CONDITIONS_NOT_SATISFIED);
          return 0;
        }
      ret = u2f_register ((U2F_REGISTER_REQ *) DATA (apdu),
                          (U2F_REGISTER_RESP *) resp);
      if (ret > 0)
        {
          user_presence_reset ();
          *resp_len = ret;
          append_sw (resp, resp_len, U2F_SW_NO_ERROR);
        }
      else
        {
          u2f_apdu_error (resp, resp_len, U2F_SW_WRONG_DATA);
        }
      break;

    case U2F_AUTHENTICATE:
      if (!attestation_cert_initialized ())
        {
          u2f_apdu_error (resp, resp_len, U2F_SW_COMMAND_NOT_ALLOWED);
          break;
        }
      if (Lc != sizeof (U2F_AUTHENTICATE_REQ))
        {
          u2f_apdu_error (resp, resp_len, U2F_SW_WRONG_LENGTH);
          break;
        }
      ret = u2f_authenticate ((U2F_AUTHENTICATE_REQ *) DATA (apdu),
                              (U2F_AUTHENTICATE_RESP *) resp);
      if (ret > 0)
        {
          if (P1 (apdu) != U2F_AUTH_CHECK_ONLY)
            {
              if (!user_presence_get ())
                {
                  u2f_apdu_error (resp, resp_len,
                                  U2F_SW_CONDITIONS_NOT_SATISFIED);
                  return 0;
                }
              u2f_inc_ctr ();
              user_presence_reset ();
              *resp_len = ret;
              append_sw (resp, resp_len, U2F_SW_NO_ERROR);
            }
          else
            {
              u2f_apdu_error (resp, resp_len, U2F_SW_CONDITIONS_NOT_SATISFIED);
            }
        }
      else
        {
          u2f_apdu_error (resp, resp_len, U2F_SW_WRONG_DATA);
        }
      break;

    case U2F_VERSION:
      if (Lc > 0)
        {
          u2f_apdu_error (resp, resp_len, U2F_SW_WRONG_LENGTH);
          break;
        }
      ret = u2f_version (resp);
      *resp_len = ret;
      append_sw (resp, resp_len, U2F_SW_NO_ERROR);
      break;

    case U2F_ATTESTATION_CERT:
      if (Lc <= U2F_EC_KEY_SIZE)
        {
          u2f_apdu_error (resp, resp_len, U2F_SW_WRONG_LENGTH);
          break;
        }
      if (attestation_cert_initialized ())
        {
          u2f_apdu_error (resp, resp_len, U2F_SW_COMMAND_NOT_ALLOWED);
          break;
        }
      ret = attestation_cert_initialize (
              Lc, (const U2F_ATTESTATION_CERT_REQ *) DATA (apdu));
      if (ret < 0)
        {
          u2f_apdu_error (resp, resp_len, U2F_SW_WRONG_DATA);
          break;
        }
      *resp_len = 0;
      append_sw (resp, resp_len, U2F_SW_NO_ERROR);
      break;

    default:
      u2f_apdu_error (resp, resp_len, U2F_SW_INS_NOT_SUPPORTED);
    }

  return 0;
}
