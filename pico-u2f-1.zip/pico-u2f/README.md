# pico-u2f

U2F (FIDO 1.0) security key firmware for the Raspberry Pi Pico (RP2040),
built by grafting the RP2040 platform layer onto the portable protocol
and crypto core of [gl-sergei/u2f-token](https://github.com/gl-sergei/u2f-token).

**This tree actually builds.** Verified with:
`pico-sdk` 2.1.0 + `gcc-arm-none-eabi` 13.2, `-DPICO_BOARD=pico`, `make` —
produces `pico_u2f.uf2` with no errors. (A handful of harmless
`-Wrestrict` warnings come from unmodified upstream `modp256r1.c`;
newer GCC is stricter about aliasing hints than the compiler this
code was originally written against. They do not affect correctness.)

## What's unchanged from gl-sergei/u2f-token

Copied byte-for-byte, no edits:

    sha256.c/h  hmac.c/h
    bn.c/h  bn-thumb1.h  muladd_256.h
    mod.c/h  modp256r1.c/h
    ec_p256r1.c/h  jpc_p256r1.c  jpc.c  jpc-ac_p256r1.h
    affine.h  field-group-select.h
    ecc.c/h  call-ec.c  call-ec_p256r1.c

`bn.c` auto-selects the Thumb-1 multiply routine (`bn-thumb1.h`) at
compile time based on the compiler's own `__thumb__`/`__thumb2__`
macros. RP2040 is Cortex-M0+ (ARMv6-M, no `umull`) — the exact CPU
class `bn-thumb1.h` was written for — so this happens automatically;
no defines needed.

`u2f-apdu.c` keeps the *original* algorithm exactly:

    priv       = HMAC-SHA256(device_key, appId || nonce)
    keyHandle  = HMAC-SHA256(device_key, priv || appId) || nonce

Only the flash addressing changed (STM32 linker-script sections ->
fixed offsets in the last 3 flash sectors) because RP2040 has no
`.device.key`/`.auth.ctr` sections to place. REGISTER, AUTHENTICATE,
VERSION and the vendor ATTESTATION_CERT command are all implemented,
not stubbed.

## What's new for RP2040

    src/main.c        single poll loop (no chopstx threads)
    src/platform.c    button/LED presence UI + flash_erase_page/flash_write
    src/random.c      pico_rand's get_rand_32() + raw ROSC bit sampling,
                      whitened with SHA-256; implements the *whole*
                      original random.h contract (random_bytes_get/free,
                      not just random_gen — bn.c's bn256_random(), used
                      for the ECDSA nonce, calls the former)
    src/u2f-hid.c/h   U2FHID framing over TinyUSB (INIT/MSG/WINK/PING)
    src/usb_descriptors.c, tusb_config.h   FIDO HID descriptor (usage
                      page 0xF1D0), VID:PID 1209:0e90 (pid.codes test range)

## Build

    git clone --branch 2.1.0 https://github.com/raspberrypi/pico-sdk
    cd pico-sdk && git submodule update --init
    export PICO_SDK_PATH=$(pwd)
    cd /path/to/pico-u2f
    mkdir build && cd build
    cmake -DPICO_BOARD=pico ..
    make -j4
    # hold BOOTSEL, plug the Pico in, then:
    cp pico_u2f.uf2 /media/$USER/RPI-RP2/

## Pins

    GP15  user-presence button to GND (internal pull-up)
    GP25  on-board LED (steady while presence window is open, blinks 3x on WINK)

## Provisioning (required before REGISTER will work)

Fresh flash means `attestation_cert_initialized()` is false — the
device answers VERSION but refuses REGISTER/AUTHENTICATE with
`COMMAND_NOT_ALLOWED` until an attestation key + certificate are
pushed in. This mirrors the original STM32 firmware's
readout-protection-friendly design: keys never touch a build
artifact or get committed to source control.

    cd tools
    pip install -r requirements.txt      # easyhid
    bash gen.sh                          # openssl: self-signed attestation cert
    python3 provision.py init            # pushes attestation.der + attestation_key.der to the device

`provision.py` is `gl-sergei/u2f-token`'s original `certtool`,
unchanged except for the USB VID (`0x1209` here vs `0x16d0` on the
original hardware) — it talks the *same* U2FHID wire protocol
(INIT then MSG-wrapped APDU with `INS=0x40`), which this firmware's
`u2f-hid.c` also implements unmodified from the scaffold. On Linux
you'll need a udev rule for the hidraw device (see original repo's
README for the pattern; swap in `idVendor==1209`, `idProduct==0e90`).

The device key itself (used to derive every site's key via HMAC,
never stored per-site) is generated on first boot from the RP2040's
hardware RNG — nothing to provision there.

Test at <https://demo.yubico.com/webauthn-technical/> with Chrome or
Firefox once provisioned.

## Honest limitation

FIDO 1.0 / U2F only, same as the upstream project — not CTAP2/FIDO2.
Fine for a custom key against U2F-era origins and the GitHub/Google
U2F APIs; modern WebAuthn-level-2 passkey flows want CTAP2, which
this firmware does not speak.

## Flash layout

Last three 4 KiB sectors of the Pico's flash:

    sector N-3   device key (32B) + sha256(key) (32B) — self-checking,
                 regenerated from hardware RNG if the check fails
    sector N-2   auth counter, 1024 slots (4096/4) of wear-leveling
                 room — one flash write per authentication, one erase
                 per 1024 authentications
    sector N-1   attestation cert: der_len (4B) + key (32B) + DER cert
                 (up to 512B); erased flash reads 0xff, so an
                 unprovisioned sector naturally reads der_len==0xffffffff

License: GPLv3, inherited from gl-sergei/u2f-token (see COPYING).
